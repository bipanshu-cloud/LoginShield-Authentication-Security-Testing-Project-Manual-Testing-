// Smooth scroll navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Add animation to elements on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe all sections
document.querySelectorAll('.section, .overview-card, .test-module, .vuln-card, .report-section').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease-in-out, transform 0.6s ease-in-out';
    observer.observe(el);
});

// Add hover effects to tables
document.querySelectorAll('.test-table tbody tr').forEach(row => {
    row.addEventListener('mouseenter', function() {
        this.style.backgroundColor = '#f0f9ff';
    });
    row.addEventListener('mouseleave', function() {
        this.style.backgroundColor = '';
    });
});

// Mobile menu toggle (if needed in future)
function toggleMobileMenu() {
    const navLinks = document.querySelector('.nav-links');
    if (navLinks) {
        navLinks.classList.toggle('active');
    }
}

// Track scroll position for navbar
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.15)';
    } else {
        navbar.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.1)';
    }
});

// Animated counter for statistics
function animateCounters() {
    const stats = document.querySelectorAll('.stat-card h3');
    const speed = 200; // milliseconds per unit

    stats.forEach(stat => {
        const target = parseInt(stat.innerText);
        const isPercent = stat.innerText.includes('%');
        let current = 0;
        const increment = target / speed;

        const updateCounter = () => {
            current += increment;
            if (current < target) {
                stat.innerText = Math.floor(current) + (isPercent ? '%' : '');
                setTimeout(updateCounter, 10);
            } else {
                stat.innerText = target + (isPercent ? '%' : '');
            }
        };

        // Only run when element is visible
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) {
                updateCounter();
                observer.unobserve(stat);
            }
        });
        observer.observe(stat);
    });
}

animateCounters();

// Add keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // Alt + T: Jump to test cases
    if (event.altKey && event.key === 't') {
        document.querySelector('#test-cases').scrollIntoView({ behavior: 'smooth' });
    }
    // Alt + V: Jump to vulnerabilities
    if (event.altKey && event.key === 'v') {
        document.querySelector('#vulnerabilities').scrollIntoView({ behavior: 'smooth' });
    }
    // Alt + R: Jump to report
    if (event.altKey && event.key === 'r') {
        document.querySelector('#report').scrollIntoView({ behavior: 'smooth' });
    }
});

// Print-friendly styles enhancement
window.addEventListener('beforeprint', function() {
    document.body.style.backgroundColor = 'white';
    document.querySelectorAll('.section').forEach(section => {
        section.style.pageBreakInside = 'avoid';
    });
});

// Add copy-to-clipboard functionality for test case IDs
document.querySelectorAll('.test-table tbody tr').forEach(row => {
    row.addEventListener('dblclick', function() {
        const testId = this.querySelector('td').innerText;
        navigator.clipboard.writeText(testId).then(() => {
            // Show a temporary tooltip
            const tooltip = document.createElement('div');
            tooltip.textContent = 'Copied: ' + testId;
            tooltip.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: #10b981;
                color: white;
                padding: 10px 20px;
                border-radius: 6px;
                z-index: 1000;
                animation: slideIn 0.3s ease-in-out;
            `;
            document.body.appendChild(tooltip);
            setTimeout(() => tooltip.remove(), 2000);
        });
    });
});

// Add CSS animation for toast notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);

// Log initialization
console.log('LoginShield QA Testing Portal Loaded Successfully');
console.log('Test Coverage: 50+ test cases across 4 modules');
console.log('Vulnerabilities Identified: 8 critical & high-severity issues');
console.log('OWASP Compliance: 100%');
